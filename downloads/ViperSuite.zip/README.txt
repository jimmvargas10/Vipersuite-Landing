================================================================
 VIPER SUITE — Installation Guide / Guía de Instalación
 Version 1.0 | vipersuite.com
================================================================

----------------------------------------------------------------
 ENGLISH
----------------------------------------------------------------

REQUIREMENTS:
  - NinjaTrader 8 (version 8.1.6.3 or higher)
  - Windows 10 or higher
  - Active internet connection (for license activation)

INSTALLATION STEPS:
  1. Open NinjaTrader 8.
  2. Go to Tools → Import → NinjaScript Add-On.
  3. Select the ViperSuite.zip file you downloaded.
  4. Click "Open". NinjaTrader will import and compile the AddOn automatically.
  5. Restart NinjaTrader when prompted.

  After restart, Viper Suite will load automatically.
  The LauncherPad will appear on your screen.

+---------------------------------------------------------------+
| IF THE LAUNCHERPAD DOES NOT APPEAR:                           |
|                                                               |
| 1. Make sure Viper Suite was imported correctly.              |
|    - In NinjaTrader, go to Tools → Import →                   |
|      NinjaScript Add-On.                                      |
|    - Select the ViperSuite.zip file again and import          |
|      it one more time.                                        |
|                                                               |
| 2. Manually compile NinjaScript files.                        |
|    - From the main NinjaTrader window (Control Center),       |
|      click on "New" in the top menu.                          |
|    - Select "NinjaScript Editor" from the dropdown.           |
|    - In the new window that opens, press the F5 key on        |
|      your keyboard, or click the "Compile" button             |
|      (the icon with a gear on it).                            |
|    - Wait until you see the message                           |
|      "Compilation successful" at the bottom.                  |
|    - Close the NinjaScript Editor window.                     |
|                                                               |
| 3. Restart NinjaTrader.                                       |
|    - Close NinjaTrader completely (also close it from         |
|      the system tray near the clock).                         |
|    - Open NinjaTrader again.                                  |
|                                                               |
| After these steps, the Viper Suite LauncherPad should         |
| appear on your screen.                                        |
+---------------------------------------------------------------+

FREE TRIAL:
  - You get 15 days of full access, no credit card required.
  - After the trial, go to Settings > License to activate.

ACTIVATION:
  1. Purchase a license at vipersuite.com
  2. You will receive a license key by email.
  3. Open NinjaTrader > Viper Suite > Settings > License.
  4. Paste your key and click Activate.

SUPPORT:
  Website : vipersuite.com
  Email   : support@vipersuite.com

----------------------------------------------------------------
 ESPAÑOL
----------------------------------------------------------------

REQUISITOS:
  - NinjaTrader 8 (versión 8.1.6.3 o superior)
  - Windows 10 o superior
  - Conexión a internet activa (para activación de licencia)

PASOS DE INSTALACIÓN:
  1. Abre NinjaTrader 8.
  2. Ve a Tools → Import → NinjaScript Add-On.
  3. Selecciona el archivo ViperSuite.zip que descargaste.
  4. Haz clic en "Open". NinjaTrader importará y compilará el AddOn automáticamente.
  5. Reinicia NinjaTrader cuando se te solicite.

  Después de reiniciar, Viper Suite se cargará automáticamente.
  El LauncherPad aparecerá en tu pantalla.

+---------------------------------------------------------------+
| SI EL LAUNCHERPAD NO APARECE:                                 |
|                                                               |
| 1. Asegúrate de que Viper Suite se importó correctamente.     |
|    - En NinjaTrader, ve a Tools → Import →                    |
|      NinjaScript Add-On.                                      |
|    - Selecciona otra vez el archivo ViperSuite.zip e          |
|      impórtalo una vez más.                                   |
|                                                               |
| 2. Compila manualmente los archivos NinjaScript.              |
|    - Desde la ventana principal de NinjaTrader (Control       |
|      Center), haz clic en "New" en el menú superior.          |
|    - Selecciona "NinjaScript Editor" del menú desplegable.    |
|    - En la nueva ventana que se abre, presiona la tecla       |
|      F5 de tu teclado, o haz clic en el botón "Compile"       |
|      (el icono con un engranaje).                             |
|    - Espera hasta ver el mensaje "Compilation successful"     |
|      (Compilación exitosa) en la parte inferior.              |
|    - Cierra la ventana del NinjaScript Editor.                |
|                                                               |
| 3. Reinicia NinjaTrader.                                      |
|    - Cierra NinjaTrader por completo (también ciérralo        |
|      desde la bandeja del sistema, cerca del reloj).          |
|    - Abre NinjaTrader de nuevo.                               |
|                                                               |
| Después de estos pasos, el LauncherPad de Viper Suite         |
| debería aparecer en tu pantalla.                              |
+---------------------------------------------------------------+

PRUEBA GRATUITA:
  - Tienes 15 días de acceso completo, sin tarjeta de crédito.
  - Al terminar el trial, ve a Settings > License para activar.

ACTIVACIÓN:
  1. Compra una licencia en vipersuite.com
  2. Recibirás una clave de licencia por correo electrónico.
  3. Abre NinjaTrader > Viper Suite > Settings > License.
  4. Pega tu clave y haz click en Activate.

SOPORTE:
  Sitio web : vipersuite.com
  Email     : support@vipersuite.com

================================================================
 © 2026 Viper Suite | vipersuite.com
================================================================
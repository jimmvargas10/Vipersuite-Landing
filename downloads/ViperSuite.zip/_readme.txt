﻿Viper Suite trial package placeholder — replace with full ViperSuite.zip before release if needed.

================================================================
 VIPER SUITE — Installation Guide / Guía de Instalación
 Version 1.0 | vipersuite.com
================================================================

----------------------------------------------------------------
 ENGLISH
----------------------------------------------------------------

REQUIREMENTS:
  - NinjaTrader 8 (version 8.1.6.3 or higher)
  - Windows 10 or higher
  - Active internet connection (for license activation)

INSTALLATION STEPS:
  1. Close NinjaTrader completely (check the system tray).
  2. Copy "ViperSuiteCore.dll" to:
       C:\Users\[YourUser]\Documents\NinjaTrader 8\bin\Custom\
  3. Open NinjaTrader.
  4. Viper Suite will load automatically.
     The LauncherPad will appear on your screen.

FREE TRIAL:
  - You get 15 days of full access, no credit card required.
  - After the trial, go to Settings > License to activate.

ACTIVATION:
  1. Purchase a license at vipersuite.com
  2. You will receive a license key by email.
  3. Open NinjaTrader > Viper Suite > Settings > License.
  4. Paste your key and click Activate.

SUPPORT:
  Website : vipersuite.com
  Email   : support@vipersuite.com

----------------------------------------------------------------
 ESPAÑOL
----------------------------------------------------------------

REQUISITOS:
  - NinjaTrader 8 (versión 8.1.6.3 o superior)
  - Windows 10 o superior
  - Conexión a internet activa (para activación de licencia)

PASOS DE INSTALACIÓN:
  1. Cierra NinjaTrader completamente (revisa la barra del sistema).
  2. Copia "ViperSuiteCore.dll" a:
       C:\Users\[TuUsuario]\Documents\NinjaTrader 8\bin\Custom\
  3. Abre NinjaTrader.
  4. Viper Suite se cargará automáticamente.
     El LauncherPad aparecerá en tu pantalla.

PRUEBA GRATUITA:
  - Tienes 15 días de acceso completo, sin tarjeta de crédito.
  - Al terminar el trial, ve a Settings > License para activar.

ACTIVACIÓN:
  1. Compra una licencia en vipersuite.com
  2. Recibirás una clave de licencia por correo electrónico.
  3. Abre NinjaTrader > Viper Suite > Settings > License.
  4. Pega tu clave y haz click en Activate.

SOPORTE:
  Sitio web : vipersuite.com
  Email     : support@vipersuite.com

================================================================
 © 2026 Viper Suite | vipersuite.com
================================================================
